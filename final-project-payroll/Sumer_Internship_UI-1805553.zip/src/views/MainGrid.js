  import React from 'react';
  import DataTable from '../utils/DataTable.js';
  import { makeStyles } from '@material-ui/core/styles';
  import Grid from '@material-ui/core/Grid';
  import Paper from '@material-ui/core/Paper';
  import Button from '@material-ui/core/Button';
  import TextField from '@material-ui/core/TextField';

  import edit from '../assets/Path 18191.svg';
  import wrong from '../assets/Path 18298.svg';  

  const useStyles = makeStyles((theme) => ({
    root: {
      flexGrow: 1,
    },

    paper: {
      padding: theme.spacing(2),
      backgroundColor: '#283a47',
    },

    predict_button: {
      backgroundColor:"#97A1A9",
      textTransform: 'none',
      color:"#ffffff",
      marginRight:'1rem',
    "&:hover": { backgroundColor:"#14AFF1",},
    "&:active": { backgroundColor:"#000000",},
    },

    corr_button: {
      backgroundColor: '#283a47',
      textTransform: 'none',
      color:"#ffffff",
      marginRight:"40vw",
    },

    buttons: {
      alignItems:'right',
      backgroundColor: '#283a47',
      textTransform: 'none',
      color:"#ffffff",
      outlineColor:"#14AFF1",
      margin: "0.5vw",
    },

    search:{
      color:'#ffffff',
      width: '15vw',
      height: '3vh',
    },

    table_style:{
      backGround:'black',
      color:'#ffffff',
      width: '14vw',
      height: '3vh',
    },
  }));
  
  const MainGrid = ({title}) => {
    const [spacing, setSpacing] = React.useState(2);
    const classes = useStyles();
  
    const handleChange = (event) => {
      setSpacing(Number(event.target.value));
    };
  
    return (
      <Grid className="grid-style" spacing={1}>
        <header className="table-name">Invoice Details</header>
        <Paper className={classes.paper} elevation={0}>
          <Button className={classes.predict_button} variant="contained">Predict</Button>
          <Button className={classes.corr_button} variant="outlined" color="inherit">View Correspondence</Button>

          <Button className={classes.buttons} variant="outlined" color="inherit">+ Add</Button>
          <Button className={classes.buttons} variant="outlined" color="inherit"><img src={edit}/>Edit </Button>
          <Button className={classes.buttons} variant="outlined" color="inherit">- Delete</Button>
          <TextField className={classes.search} id="outlined-basic" label="Search by Invoice Number" variant="outlined" color="inherit"> </TextField>
        </Paper>
        <Paper>
          <DataTable className={classes.table_style} pageSize={5} checkboxSelection />
        </Paper>
      </Grid>
    );
  };

  export default MainGrid;