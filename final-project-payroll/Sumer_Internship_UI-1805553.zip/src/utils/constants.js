export const SERVER_URL = 'http://localhost:8000/';
export const ROLL_NUMBER = '1805553_HRC';