import React from "react";
import ReactDOM from "react-dom";
import ProjectsWithClass from "./ProjectsWithClass";
// import ProjectsWithCreateClass from "./ProjectsWithCreateClass";

const rootElement = document.getElementById("root");
ReactDOM.render(<ProjectsWithClass />, rootElement);
